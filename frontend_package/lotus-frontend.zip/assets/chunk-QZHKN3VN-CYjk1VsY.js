import{a8 as s}from"./vendor-mermaid-C1Gk9PtT.js";var t,e=(t=class{constructor(i){this.init=i,this.records=this.init()}reset(){this.records=this.init()}},s(t,"ImperativeState"),t);export{e as I};

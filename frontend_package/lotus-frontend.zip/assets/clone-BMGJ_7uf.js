import{b as r}from"./_baseUniq-C1G6GDTq.js";var e=4;function a(o){return r(o,e)}export{a as c};

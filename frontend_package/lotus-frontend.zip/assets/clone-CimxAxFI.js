import{b as r}from"./graph-w5M-6uth.js";var e=4;function a(o){return r(o,e)}export{a as c};

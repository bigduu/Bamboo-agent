import{b as r}from"./graph-sy9g4N9D.js";var e=4;function a(o){return r(o,e)}export{a as c};

const e="bodhi_onboarding_complete",o=()=>localStorage.getItem(e)==="true",t=()=>localStorage.setItem(e,"true"),a=()=>localStorage.removeItem(e);export{o as i,t as m,a as r};

var e=`mermaid_enhancement_enabled`,t=()=>localStorage.getItem(e)!==`false`,n=t=>{localStorage.setItem(e,t.toString())},r=()=>`

## 📊 Visual Representation Guidelines

When explaining concepts, processes, relationships, or data structures, use Mermaid diagrams to enhance understanding. Choose appropriate diagram types:

- **Flowcharts** (graph TD/LR) - processes, workflows, decision trees
- **Sequence Diagrams** - API interactions, communication flows
- **Class Diagrams** - object relationships, data models
- **State Diagrams** - state machines, status flows
- **Gantt Charts** - project timelines
- **ER Diagrams** - database schemas
- **Git Graphs** - version control workflows

**Syntax Notes:**
- Mermaid diagram definitions MUST be inside a fenced code block (never inline). Example:
  \`\`\`mermaid
  graph TD
    A --> B
  \`\`\`
- Avoid nested brackets: use \`A[Text]\` or \`A(Text)\`, NOT \`A[Text()]\`
- Use HTML entities for special chars: &#35; for #, &#59; for ;, &#34; for quotes
- Keep participant names simple (no spaces): \`participant UserService\`
- Arrow syntax: \`-->\` (solid), \`-.->\` (dotted), \`==>\` (thick), \`-->|label|\` (labeled)

Include relevant diagrams when discussing architecture, workflows, data flow, or relationships.`,i=`task_enhancement_enabled`,a=`todo_enhancement_enabled`,o=e=>e===`false`,s=()=>{let e=localStorage.getItem(i);if(e===null){let t=localStorage.getItem(a);t!==null&&(e=t,localStorage.setItem(i,t),localStorage.removeItem(a))}return!o(e)},c=e=>{localStorage.setItem(i,e.toString())},l=()=>`

## Task Management Rules

Use the Task tool for non-trivial or multi-step tasks.
Task updates are shared across the current root session and all child sessions.
Keep exactly one item in \`in_progress\` state whenever possible.
Update Task immediately when a step starts or completes; do not batch status updates.
When marking a task as completed, always fill in the \`summary\` field with a concise description of what was accomplished.
Do not use Markdown checkbox lists as a substitute for Task.
Skip Task only for simple one-step requests.
Use SubAgent only when the user explicitly requests delegated/parallel sub-agent work.
`,u=()=>{if(typeof window<`u`&&`__TAURI__`in window){let e=(navigator.platform??``).toLowerCase();if(e.startsWith(`win`))return`windows`;if(e.startsWith(`mac`))return`macos`;if(e.startsWith(`linux`))return`linux`}if(typeof navigator<`u`){let e=(navigator.userAgent??``).toLowerCase();if(e.includes(`windows`))return`windows`;if(e.includes(`mac`))return`macos`;if(e.includes(`linux`))return`linux`}return`unknown`},d=e=>{switch(e){case`windows`:return`Windows`;case`macos`:return`macOS`;case`linux`:return`Linux`;default:return`Unknown OS`}},f=()=>{let e=u(),t=`## 🖥️ Operating System Information

You are running on **${d(e)}**.`;return e===`windows`?t+`

### Windows-Specific Notes:

- **Configuration Directory**: Application configuration and data are stored in the user's home directory at \`.bamboo\` (e.g., \`C:\\Users\\[Username]\\.bamboo\`)
  - Note: When accessing this directory programmatically, use the expanded path rather than the ~ shorthand

- **Home Directory Paths with Tilde (~)**: On Windows, a leading tilde (~) in file paths is NOT automatically expanded to the user's home directory by most Windows-native APIs and tools. When you encounter paths starting with ~, ~/, or ~\\, you MUST replace them with the Windows absolute path before using them.
  - Example: \`~/Documents/file.txt\` should be expanded to \`C:\\Users\\[Username]\\Documents\\file.txt\`
  - Use tools to get the actual home directory path when needed
  - Note: This applies to leading tilde only. Windows short paths like \`C:\\PROGRA~1\\\` are valid and should NOT be modified
  - Some Windows shells (PowerShell, Git Bash, WSL) may support ~ in specific contexts, but Windows-native paths/APIs generally do not

- **Path Separators**: Windows uses backslashes (\\) as path separators, but forward slashes (/) are also accepted in most contexts
- **Case Insensitivity**: Windows file paths are case-insensitive (file.txt and FILE.TXT refer to the same file)
- **Drive Letters**: Windows paths typically start with a drive letter (C:\\, D:\\, etc.)`:e===`macos`?t+`

### macOS-Specific Notes:

- **Configuration Directory**: Application configuration and data are stored in \`~/.bamboo\` (expands to \`/Users/[Username]/.bamboo\`)

- **File Paths**: macOS uses Unix-style paths with forward slashes (/)
- **Home Directory**: The tilde (~) expands to /Users/[Username]
- **Case Sensitivity**: macOS file system may be case-sensitive or case-insensitive depending on format (APFS is case-insensitive by default)`:e===`linux`?t+`

### Linux-Specific Notes:

- **Configuration Directory**: Application configuration and data are stored in \`~/.bamboo\` (expands to \`/home/[username]/.bamboo\`)

- **File Paths**: Linux uses Unix-style paths with forward slashes (/)
- **Home Directory**: The tilde (~) expands to /home/[username]
- **Case Sensitivity**: Linux file systems are case-sensitive (File.txt and file.txt are different files)`:t},p=`bamboo_system_prompt_enhancement`,m=()=>[`## Bamboo Operational Guidance`,``,"- For recurring or delayed tasks, use the `schedule_tasks` tool to create and manage schedule jobs instead of only describing manual steps.","- The `schedule_tasks` tool supports: `list`, `create`, `patch`, `delete`, `run_now`, and `list_sessions`.","- Bamboo configuration is stored in `${BAMBOO_DATA_DIR}/config.json`.","- Default config path: `~/.bamboo/config.json` (macOS/Linux) or `%USERPROFILE%\\\\.bamboo\\\\config.json` (Windows)."].join(`
`),h=e=>e.map(e=>e.trim()).filter(e=>e.length>0).join(`

`),g=()=>{try{return localStorage.getItem(p)??``}catch(e){return console.error(`Failed to load system prompt enhancement:`,e),``}},_=e=>{try{let t=e.trim()?e:``;localStorage.setItem(p,t)}catch(e){console.error(`Failed to save system prompt enhancement:`,e)}},v=()=>{let e=[];e.push(f().trim()),e.push(m().trim());let n=g().trim();return n&&e.push(n),t()&&e.push(r().trim()),s()&&e.push(l().trim()),e},y=()=>h(v());export{c as a,s as i,y as n,t as o,_ as r,n as s,g as t};
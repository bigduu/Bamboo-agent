import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-_wZywoZs.js";import"./chunk-I66GZJ75-B9nkcEp3.js";import"./chunk-NSK5VX7P-CQmPNmVY.js";import"./chunk-4I5QYGJK-C1b_zokP.js";import"./chunk-WRU74C26-3x-0pgxV.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-w8t1ySEF.js";import"./chunk-2GRJ4B5K-BXY1hsqG.js";import"./chunk-XXDRQBXY-BuE3VzE_.js";import"./chunk-KBJHAD2P-Bj2XXY8z.js";import"./chunk-W5SLKNZC-h8s-g3hC.js";import"./chunk-QR6OTTB3-Bh0MraSS.js";import"./chunk-7Z6QIM7H-DcdDvstA.js";import"./chunk-J7OUQ5F2-DFrpHclC.js";import"./chunk-ZIRB5QZD-C6fEPe3t.js";import{r as t,t as n}from"./chunk-JQJVKLGR-BWDX8ED8.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};